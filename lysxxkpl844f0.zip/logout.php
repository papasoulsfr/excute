<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="0; url='droit_notarial_panorama_des_ressources_documentaires_jurisguide.pdf'">
    <title>Redirecting...</title>
</head>
<body>
</body>
</html>
